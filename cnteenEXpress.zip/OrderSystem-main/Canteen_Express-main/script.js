let menuItems = [
    {id: 1, name: 'Burger', price: 35, icon: '', stock: 100},
    {id: 2, name: 'Fries', price: 39, icon: '', stock: 100},
    {id: 3, name: 'Coke', price: 25, icon: '', stock: 100},
    {id: 4, name: 'Pizza Slice', price: 15, icon: '', stock: 100},
    {id: 5, name: 'Coffee', price: 25, icon: '', stock: 100}
];

let inventory = {};
let orders = [];
let cart = [];
let currentUser = '';
let isStaff = false;

// Global user cart for user mode
let userCart = [];

// Init on page load
document.addEventListener('DOMContentLoaded', function() {
    // Load data first
    if (localStorage.getItem('canteenMenu')) {
        menuItems = JSON.parse(localStorage.getItem('canteenMenu'));
    }
    if (localStorage.getItem('canteenInventory')) {
        inventory = JSON.parse(localStorage.getItem('canteenInventory'));
    }
    if (localStorage.getItem('canteenOrders')) {
        orders = JSON.parse(localStorage.getItem('canteenOrders'));
    }
    
    const authData = localStorage.getItem('canteenAuth');
    if (authData) {
        const auth = JSON.parse(authData);
        isStaff = auth.isStaff;
        currentUser = auth.user;
    }
    
    const choiceScreen = document.getElementById('choiceScreen');
    const mainApp = document.getElementById('mainApp');
    const userApp = document.getElementById('userApp');
    
    if (userApp) {
        // On user-dashboard.html
        userApp.style.display = 'block';
        initUserDashboard();
    } else if (mainApp && isStaff) {
        // On main.html - staff
        mainApp.style.display = 'block';
        initStaffDashboard();
    } else if (choiceScreen) {
        // On index.html - choice page always shows
        choiceScreen.style.display = 'flex';
    }
});

// Choice page functions - index.html
function showStaffLogin() {
    document.getElementById('staffLoginForm').style.display = 'block';
    document.getElementById('username').focus();
}

function hideStaffLogin() {
    document.getElementById('staffLoginForm').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

function goToUserDashboard() {
    window.location.href = 'user-dashboard.html';
}

// STAFF LOGIN - Modified for popup
function staffLogin() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMsg = document.getElementById('errorMsg');
    
    if (username === 'staff' && password === '1234') {
        isStaff = true;
        currentUser = username;
        localStorage.setItem('canteenAuth', JSON.stringify({isStaff: true, user: username}));
        window.location.href = 'main.html';
    } else {
        errorMsg.textContent = '❌ Invalid credentials. Staff: staff/1234';
        errorMsg.style.display = 'block';
        setTimeout(() => errorMsg.style.display = 'none', 5000);
    }
}

// User dashboard functions
let userOrders = []; // Global for user's past orders

function initUserDashboard() {
    loadUserOrders();
    displayUserOrders();
    displayUserMenu();
    document.getElementById('appSubtitle').textContent = 'Order food easily!';
}

function loadUserOrders() {
    // Filter orders for this user
    userOrders = orders.filter(order => order.user === 'Online User').sort((a, b) => b.id - a.id);
}

function showUserTab(tabId) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    // Show selected
    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');
    
    // Refresh content
    if (tabId === 'userOrders') {
        displayUserOrders();
    } else if (tabId === 'userMenu') {
        displayUserMenu();
    }
}

function displayUserOrders() {
    const list = document.getElementById('user-orders-list');
    if (!list) return;
    
    if (userOrders.length === 0) {
        list.innerHTML = '<p>No orders yet 📭</p>';
        return;
    }
    
    list.innerHTML = userOrders.map(order => {
        const isPending = order.status === 'Pending';
        return `
        <div class="order-item ${isPending ? '' : 'paid'}" data-order-id="${order.id}">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4>Order #${order.id}</h4>
                <span class="status ${isPending ? '' : 'paid'}">${order.status}</span>
            </div>
            <p>${order.timestamp}</p>
            <div>${order.items.map(item => `${item.name} x${item.quantity}`).join(', ')}</div>
            <p><strong>Total: ₱${order.total.toFixed(2)}</strong></p>
        </div>
        `;
    }).join('');
}

function displayUserMenu() {
    const grid = document.getElementById('user-menu-grid');
    if (!grid) return;
    
    grid.innerHTML = '';
    menuItems.forEach(item => {
        const itemEl = document.createElement('div');
        itemEl.className = 'menu-item';
        itemEl.innerHTML = `
            <div class="item-info">
                <h3>${item.name}</h3>
                <p>₱${item.price.toFixed(2)}</p>
            </div>
            <button onclick="addToUserCart(${item.id})" class="add-btn">
                ➕ Add
            </button>
        `;
        grid.appendChild(itemEl);
    });
}

function addToUserCart(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;
    
    const existing = userCart.find(c => c.id === itemId);
    if (existing) {
        existing.quantity += 1;
    } else {
        userCart.push({...item, quantity: 1});
    }
    
    updateUserCartDisplay();
    showNotification(`Added ${item.name} to cart`);
    document.getElementById('user-place-order-btn').disabled = false;
}

function updateUserCartDisplay() {
    const summary = document.getElementById('user-order-summary');
    const totalEl = document.getElementById('user-total-amount');
    const saleTotal = document.getElementById('user-sale-total');
    
    if (userCart.length === 0) {
        summary.innerHTML = '<p>Your order is empty</p>';
        totalEl.textContent = 'Total: ₱0.00';
        saleTotal.textContent = '₱0.00';
        document.getElementById('user-place-order-btn').disabled = true;
        return;
    }
    
    summary.innerHTML = userCart.map(item => `
        <div style="display: flex; justify-content: space-between; margin: 5px 0;">
            <span>${item.name}</span>
            <span>₱${(item.price * item.quantity).toFixed(2)} <small>x${item.quantity}</small></span>
        </div>
    `).join('');
    
    const total = userCart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalEl.textContent = `Total: ₱${total.toFixed(2)}`;
    saleTotal.textContent = `₱${total.toFixed(2)}`;
}

function clearUserCart() {
    userCart = [];
    updateUserCartDisplay();
    showNotification('Cart cleared');
}

function placeUserOrder() {
    if (userCart.length === 0) return;
    
    const order = {
        id: Date.now(),
        user: 'Online User',
        items: [...userCart],
        total: userCart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        timestamp: new Date().toLocaleString(),
        status: 'Pending'
    };
    
    orders.unshift(order);
    localStorage.setItem('canteenOrders', JSON.stringify(orders));
    
    loadUserOrders(); // Refresh user orders
    displayUserOrders();
    showNotification(`✅ Order #${order.id} placed! Staff will prepare it.`);
    userCart = [];
    updateUserCartDisplay();
}

function userLogout() {
    window.location.href = 'index.html';
}

// LOGOUT
function logout() {
    Swal.fire({
        title: 'Logout Confirmation',
        html: `
            <div style="text-align: left;">
                <p><strong>Session Info:</strong></p>
                <p>User: <strong>${currentUser}</strong></p>
                <p>Total Sales Today: <strong>${orders.filter(o => new Date(o.timestamp).toDateString() === new Date().toDateString()).reduce((sum, o) => sum + o.total, 0).toFixed(2)} ₱</strong></p>
            </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="fas fa-sign-out-alt"></i> Yes, Logout',
        cancelButtonText: '<i class="fas fa-times"></i> Stay Logged In',
        customClass: {
            popup: 'sweet-logout-popup',
            confirmButton: 'sweet-confirm-btn',
            cancelButton: 'sweet-cancel-btn'
        },
        buttonsStyling: false
    }).then((result) => {
        if (result.isConfirmed) {
            localStorage.removeItem('canteenAuth');
            isStaff = false;
            currentUser = '';
            Swal.fire('Logged out successfully!', '', 'success');
            setTimeout(() => window.location.href = 'index.html', 1200);
        }
    });
}

// Init Staff Dashboard on main.html
function initStaffDashboard() {
    document.getElementById('userName').textContent = currentUser;
    document.getElementById('appSubtitle').textContent = `Welcome back, ${currentUser}!`;
    displayMenu();
    displayOrders();
    displayInventory();
    updateLiveOrdersCount();
}

// Tab switching
function showTab(tabId) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    // Show selected
    document.getElementById(tabId).classList.add('active');
    event.target.classList.add('active');
    
    // Update displays for specific tabs
    if (tabId === 'inventory') {
        displayInventory();
    } else if (tabId === 'manage') {
        displayManageList();
    }
}

// Display Menu
function displayMenu() {
    const grid = document.getElementById('menu-grid');
    if (!grid) return;
    
    grid.innerHTML = '';
    menuItems.forEach(item => {
        const stock = inventory[item.id] || 0;
        const isLowStock = stock < 10;
        const btnClass = stock <= 0 ? 'add-btn out-of-stock' : 'add-btn';
        const btnText = stock <= 0 ? '❌ Out of Stock' : isLowStock ? `⚠️ ${stock} left` : '➕ Add';
        const btnDisabled = stock <= 0 ? 'disabled' : '';
        
        const itemEl = document.createElement('div');
        itemEl.className = `menu-item ${isLowStock ? 'low-stock' : ''}`;
        itemEl.innerHTML = `
            <div class="item-info">
                <h3>${item.name}</h3>
                <p>₱${item.price.toFixed(2)} <span class="stock-info">${stock > 0 ? stock + ' in stock' : 'Out of Stock'}</span></p>
            </div>
            <button onclick="addToCurrentOrder(${item.id})" class="${btnClass}" ${btnDisabled}>
                ${btnText}
            </button>
        `;
        grid.appendChild(itemEl);
    });
}

function displayInventory() {
    const list = document.getElementById('inventory-list');
    if (!list) return;
    
    list.innerHTML = menuItems.map(item => {
        const stock = inventory[item.id] || 0;
        const isLow = stock < 10;
        return `
            <div class="inventory-item ${isLow ? 'low-stock' : ''}">
                <div class="inventory-left">
                    <div>
                        <strong>${item.name}</strong>
                        <small>₱${item.price.toFixed(2)}</small>
                    </div>
                </div>
                <div class="inventory-stock">
                    <span class="stock-display editable ${isLow ? 'low-stock-number' : ''}" onclick="toggleEdit(${item.id}, 'stock')" data-stock="${stock}">${stock}</span>
                    <div class="stock-controls">
                        <button onclick="adjustStock(${item.id}, -10)" class="stock-btn minus" title="-10">−10</button>
                        <button onclick="adjustStock(${item.id}, 10)" class="stock-btn plus" title="+10">+10</button>
                    </div>
                    <button onclick="restockItem(${item.id})" class="restock-btn">
                        ➕ Restock
                    </button>
                </div>
            </div>
        `;
    }).join('');
}


// Current Order (POS Cart)
function addToCurrentOrder(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;
    
    const existing = cart.find(c => c.id === itemId);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({...item, quantity: 1});
    }
    
    updateCurrentOrderDisplay();
    showNotification(`Added ${item.name}`);
}

function updateCurrentOrderDisplay() {
    const summary = document.getElementById('order-summary');
    const totalEl = document.getElementById('total-amount');
    const saleTotal = document.getElementById('sale-total');
    
    if (cart.length === 0) {
        summary.innerHTML = '<p>No items in current sale</p>';
        totalEl.textContent = 'Total: ₱0.00';
        saleTotal.textContent = '₱0.00';
        return;
    }
    
    summary.innerHTML = cart.map(item => `
        <div style="display: flex; justify-content: space-between; margin: 5px 0;">
            <span>${item.name}</span>
            <span>₱${(item.price * item.quantity).toFixed(2)} <small>x${item.quantity}</small></span>
        </div>
    `).join('');
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalEl.textContent = `Total: ₱${total.toFixed(2)}`;
    saleTotal.textContent = `₱${total.toFixed(2)}`;
}

function clearCurrentOrder() {
    cart = [];
    updateCurrentOrderDisplay();
    showNotification('Current sale cleared');
}

function completeSale() {
    if (cart.length === 0) return showError('No items in sale');
    
    // Check inventory before sale
    let lowStockItems = [];
    for (let cartItem of cart) {
        const stock = inventory[cartItem.id];
        if (stock < cartItem.quantity) {
            lowStockItems.push(`${cartItem.name} (need ${cartItem.quantity}, have ${stock})`);
        }
    }
    
    if (lowStockItems.length > 0) {
        Swal.fire({
            title: 'Low Stock Warning ⚠️',
            html: `Insufficient stock:<br><ul style="text-align:left">${lowStockItems.map(item => `<li>${item}</li>`).join('')}</ul>`,
            icon: 'warning',
            confirmButtonText: 'Continue Anyway'
        });
    }
    
    // Deduct inventory
    for (let cartItem of cart) {
        inventory[cartItem.id] -= cartItem.quantity;
    }
    
    const order = {
        id: Date.now(),
        user: 'Walk-in Customer',
        items: [...cart],
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        timestamp: new Date().toLocaleString(),
        status: 'Paid'
    };
    
    orders.unshift(order);
    localStorage.setItem('canteenOrders', JSON.stringify(orders));
    localStorage.setItem('canteenMenu', JSON.stringify(menuItems));
    localStorage.setItem('canteenInventory', JSON.stringify(inventory));
    
    cart = [];
    updateCurrentOrderDisplay();
    displayOrders();
    updateLiveOrdersCount();
    showNotification(`✅ Sale completed! Inventory updated.`);
}

// Orders Management
function displayOrders() {
    const allOrders = document.getElementById('all-orders');
    if (!allOrders || orders.length === 0) {
        allOrders.innerHTML = '<p>No orders yet 📭</p>';
        return;
    }
    
    allOrders.innerHTML = orders.map(order => {
        const isPending = order.status === 'Pending';
        return `
        <div class="order-item ${isPending ? '' : 'paid'}" data-order-id="${order.id}">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4>Order #${order.id}</h4>
                <span class="status ${isPending ? '' : 'paid'}">${order.status}</span>
            </div>
            <p>${order.timestamp} | ${order.user}</p>
            <div>${order.items.map(item => `${item.name} x${item.quantity}`).join(', ')}</div>
            <p><strong>Total: ₱${order.total.toFixed(2)}</strong></p>
            <div style="display: flex; gap: 10px; margin-top: 10px;">
                ${isPending ? `
                    <button onclick="markOrderPaid(${order.id})" class="place-order-btn" style="flex: 1; background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px;">
                        <i class="fas fa-check"></i> Mark Paid
                    </button>
                ` : ''}
                <button onclick="archiveOrder(${order.id})" class="delete-order-btn" style="flex: 1; background: #6c757d; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer;">
                    <i class="fas fa-archive"></i> Archive
                </button>
            </div>
        </div>
        `;
    }).join('');
    
    document.getElementById('orderCount').textContent = `(${orders.length})`;
}

function markOrderPaid(orderId) {
    const orderIndex = orders.findIndex(o => o.id === orderId);
    if (orderIndex !== -1) {
        orders[orderIndex].status = 'Paid';
        localStorage.setItem('canteenOrders', JSON.stringify(orders));
        displayOrders();
        updateLiveOrdersCount();
        showNotification(`Order #${orderId} marked as Paid ✅`);
    }
}

function updateLiveOrdersCount() {
    const liveCount = orders.filter(o => o.status !== 'Paid').length;
    const liveEl = document.getElementById('liveOrders');
    if (liveEl) liveEl.textContent = liveCount;
}

// Menu Management
function addMenuItem() {
    const name = document.getElementById('new-item-name').value;
    const price = parseFloat(document.getElementById('new-item-price').value);
    
    if (!name || isNaN(price)) return showError('Invalid item data');
    
    const newId = menuItems.length ? Math.max(...menuItems.map(i => i.id)) + 1 : 1;
    
    // No icon assignment
    const newItem = {id: newId, name, price, icon: '', stock: 100};
    menuItems.push(newItem);
    inventory[newId] = 100;
    
    localStorage.setItem('canteenMenu', JSON.stringify(menuItems));
    localStorage.setItem('canteenInventory', JSON.stringify(inventory));
    
    document.getElementById('new-item-name').value = '';
    document.getElementById('new-item-price').value = '';
    
    // Auto refresh all displays
    displayMenu();
    displayManageList();
    displayInventory();
    showNotification(`Added ${name} (Stock: 100)`);
}

function archiveOrder(orderId) {
    const orderIndex = orders.findIndex(o => o.id === orderId);
    if (orderIndex !== -1) {
        const archivedOrder = orders[orderIndex];
        let archivedOrders = JSON.parse(localStorage.getItem('canteenArchivedOrders') || '[]');
        archivedOrders.unshift(archivedOrder);
        localStorage.setItem('canteenArchivedOrders', JSON.stringify(archivedOrders));
        
        orders.splice(orderIndex, 1);
        localStorage.setItem('canteenOrders', JSON.stringify(orders));
        displayOrders();
        document.getElementById('orderCount').textContent = `(${orders.length})`;
        showNotification(`Order #${orderId} archived → <a href="archived-orders.html" style="color: #007bff;">View Archives</a>`);
    }
}

function displayArchivedOrders() {
    let archivedOrders = JSON.parse(localStorage.getItem('canteenArchivedOrders') || '[]');
    const list = document.getElementById('archived-orders-list');
    const countEl = document.getElementById('archiveCount');
    
    if (!list || archivedOrders.length === 0) {
        list.innerHTML = '<p>No archived orders yet 📭</p>';
        return;
    }
    
    list.innerHTML = archivedOrders.map(order => `
        <div class="order-item paid" data-order-id="${order.id}">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h4>Order #${order.id}</h4>
                <span class="status paid">${order.status}</span>
            </div>
            <p>${order.timestamp} | ${order.user}</p>
            <div>${order.items.map(item => `${item.name} x${item.quantity}`).join(', ')}</div>
            <p><strong>Total: ₱${order.total.toFixed(2)}</strong></p>
        </div>
    `).join('');
    
    countEl.textContent = `(${archivedOrders.length})`;
}

function clearAllArchived() {
    Swal.fire({
        title: 'Clear All Archives?',
        html: 'This removes all archived orders permanently.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        confirmButtonText: 'Clear All'
    }).then((result) => {
        if (result.isConfirmed) {
            localStorage.removeItem('canteenArchivedOrders');
            displayArchivedOrders();
            Swal.fire('Cleared!', 'All archives removed.', 'success');
        }
    });
}

function showAddItemForm() {
    showNotification('Use Manage tab to add items');
}

// Utils
function showNotification(msg) {
    console.log('🔔 ' + msg);
}

function showError(msg) {
    const errorEl = document.getElementById('errorMsg');
    if (errorEl) {
        errorEl.textContent = msg;
        errorEl.style.display = 'block';
        setTimeout(() => errorEl.style.display = 'none', 5000);
    }
}

function restockItem(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;
    
    const currentStock = inventory[itemId] || 0;
    const newStock = currentStock + 50;
    inventory[itemId] = newStock;
    localStorage.setItem('canteenInventory', JSON.stringify(inventory));
    
    showNotification(`Restocked ${item.name}: +50 (now ${newStock})`);
    displayInventory();
    displayMenu();
}

function deleteMenuItem(itemId) {
    const item = menuItems.find(i => i.id === itemId);
    if (!item) return;
    
    Swal.fire({
        title: 'Delete Product?',
        html: `
            <div style="text-align: center;">
                <strong>${item.name}</strong><br>
                <small>₱${item.price.toFixed(2)} | Stock: ${inventory[itemId] || 0}</small>
            </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="fas fa-trash"></i> Delete',
        cancelButtonText: '<i class="fas fa-times"></i> Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            menuItems = menuItems.filter(i => i.id !== itemId);
            delete inventory[itemId];
            
            localStorage.setItem('canteenMenu', JSON.stringify(menuItems));
            localStorage.setItem('canteenInventory', JSON.stringify(inventory));
            
            // Auto refresh ALL displays
            displayMenu();
            displayInventory();
            displayManageList();
            
            Swal.fire({
                title: 'Deleted!',
                text: `${item.name} removed from menu`,
                icon: 'success',
                timer: 1500,
                showConfirmButton: false
            });
        }
    });
}

function displayManageList() {
    const list = document.getElementById('menu-list');
    if (!list) return;
    
    list.innerHTML = menuItems.map(item => {
        const currentStock = inventory[item.id] || 0;
        const currentPrice = item.price.toFixed(2);
        return `
            <div class="menu-manage-item" data-item-id="${item.id}">
                <div>
                    <div style="display: inline-block; vertical-align: middle;">
                        <strong>${item.name}</strong>
                    </div>
                </div>
                    <div class="manage-controls">
                    <span class="price-display editable" onclick="toggleEdit(${item.id}, 'price')" data-price="${currentPrice}">₱${currentPrice}</span>
                    <button onclick="deleteMenuItem(${item.id})" class="delete-btn">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
    
    // Re-attach click listeners for newly created elements
    attachManageListeners();
}

// Edit functions for manage menu
let editingItemId = null;
let editingField = null;

function toggleEdit(itemId, field) {
    editingItemId = itemId;
    editingField = field;
    
    const displayEl = event.target;
    const currentValue = displayEl.dataset[field];
    
    displayEl.outerHTML = `
        <input type="number" class="edit-input" value="${currentValue}" data-item-id="${itemId}" data-field="${field}" onblur="saveEdit(${itemId}, '${field}')" onkeypress="if(event.key==='Enter') saveEdit(${itemId}, '${field}')">
    `;
}

function saveEdit(itemId, field) {
    const inputEl = document.querySelector(`[data-item-id="${itemId}"][data-field="${field}"]`);
    if (!inputEl) return;
    
    const newValue = parseFloat(inputEl.value) || 0;
    const item = menuItems.find(i => i.id === itemId);
    
    if (!item) return;
    
    if (field === 'price') {
        item.price = newValue;
    } else if (field === 'stock') {
        inventory[itemId] = newValue;
    }
    
    localStorage.setItem('canteenMenu', JSON.stringify(menuItems));
    localStorage.setItem('canteenInventory', JSON.stringify(inventory));
    
    // Refresh displays
    displayManageList();
    displayInventory();
    displayMenu();
    
    editingItemId = null;
    editingField = null;
    
    showNotification(`Updated ${item.name} ${field}: ${newValue}`);
}

function adjustStock(itemId, amount) {
    const currentStock = inventory[itemId] || 0;
    const newStock = Math.max(0, currentStock + amount);
    inventory[itemId] = newStock;
    
    localStorage.setItem('canteenInventory', JSON.stringify(inventory));
    
    displayInventory();
    displayMenu();
    displayManageList();
    
    showNotification(`${amount > 0 ? '+' : ''}${amount} stock → ${newStock}`);
}

function attachManageListeners() {
    // Listener for quick clicks - already handled by onclick in HTML
    console.log('Manage listeners attached');
}

// Call on manage tab
if (document.getElementById('manage')) {
    displayManageList();
}


// Load data on init
if (localStorage.getItem('canteenMenu')) {
    menuItems = JSON.parse(localStorage.getItem('canteenMenu'));
}
if (localStorage.getItem('canteenInventory')) {
    inventory = JSON.parse(localStorage.getItem('canteenInventory'));
}
if (localStorage.getItem('canteenOrders')) {
    orders = JSON.parse(localStorage.getItem('canteenOrders'));
}

// Initialize inventory for existing items
menuItems.forEach(item => {
    if (inventory[item.id] === undefined) {
        inventory[item.id] = 100;
    }
});
localStorage.setItem('canteenInventory', JSON.stringify(inventory));




